export let suppliers = [{id: 1, name: "Abhay Pratap Singh", phoneno: "9857587555", email: "abhayrajput9958@gmail.com",address: "shankar vihar colony quarsi Ramghat Road Aligarh"},
{id: 2, name: "Chandra Rawat", phoneno: "6646464644", email: "ChandraRawat@gmail.com",address: "shadipur colony uttrakhand"},
{id: 3, name: "Mohan Chandra", phoneno: "9857979795", email: "Mohantiwari@gmail.com",address: "jahola  vihar colony noida"},
{id: 4, name: "Abhay Pratap Singh", phoneno: "9857587555", email: "abhayrajput9958@gmail.com",address: "shankar vihar colony quarsi Ramghat Road Aligarh"},
{id: 5, name: "Abhay Pratap Singh", phoneno: "9857587555", email: "abhayrajput9958@gmail.com",address: "shankar vihar colony quarsi Ramghat Road Aligarh"},
{id: 6, name: "Abhay Pratap Singh", phoneno: "9857587555", email: "abhayrajput9958@gmail.com",address: "shankar vihar colony quarsi Ramghat Road Aligarh"},
]
